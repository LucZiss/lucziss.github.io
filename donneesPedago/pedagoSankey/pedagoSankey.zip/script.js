
var units = "dependance(s)";

var margin = {
        top: 20,
        right: 300,
        bottom: 20,
        left: 20
    },
    width = window.innerWidth - margin.left - margin.right,
    height = window.innerHeight - margin.top - margin.bottom;

var svgPadding = {
  top : 55, 
  right : 35, 
  bottom : 60, 
  left : 25
};

var formatNumber = d3.format(",.0f"),
    format = function(d) {
        return formatNumber(d) + " " + units;
    },
    color = d3.scaleOrdinal(d3.schemeCategory10);

var svg = d3.select("body").append("svg")
    .attr("id", "chart")
    .attr("width", width)
    .attr("height", height)
    .append("g")
    .attr("transform",
        "translate(" + svgPadding.left + "," + svgPadding.top + ")");

var tip = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("opacity", 0);

var sankey = d3.sankey()
    .nodeWidth(100)
    .nodePadding(8)
    .size([width - svgPadding.right - svgPadding.left, height - svgPadding.bottom]);

var path = sankey.link();

zoomHandler(svg, 3);

d3.json("pedago.json").then(function(data) {

    var graph = {
        "nodes": data,
        "links": getLinks(data)
    }

    sankey
        .nodes(graph.nodes)
        .links(graph.links)
        .layout(32);

    var link = svg.append("g").selectAll(".link")
        .data(graph.links)
        .enter().append("path")
        .attr("class", "link")
        .attr("d", path)
        .style("stroke-width", function(d) {
            return Math.max(1, d.dy);
        })
        .sort(function(a, b) {
            return b.dy - a.dy;
        });

    displayLinks(link);

    var node = svg.append("g").selectAll(".node")
        .data(graph.nodes)
        .enter().append("g")
        .attr("class", "node")
        .attr("transform", function(d) {
            return "translate(" + d.x + "," + d.y + ")";
        })
        .attr("dataX", function(d) {
            return d.x;
        })
        .attr("width", sankey.nodeWidth())
        .call(d3.drag()
            .subject(function(d) {
                return d;
            })
            .on("start", function() {
                this.parentNode.appendChild(this);
            })
            .on("drag", dragmove));

    var nodeRects = node.append("rect")
        .attr("height", function(d) {
            return d.dy;
        })
        .attr("width", sankey.nodeWidth())
        .attr("rx", 2)
        .attr("ry", 2)
        .style("fill", applyColours)
        .style("stroke", function(d) {
            return d3.rgb(d.color).darker(2);
        });

    displayNodes(nodeRects);
    var currentFilters = filterSkill(link, node, "Realiser","Professionnaliser","Appliquer", "Construire", "Programmer", "Formaliser");

    var nodeTexts = node.append("text")
        .attr("y", function(d) {
            return d.dy / 2;
        })
        .attr("dy", ".35em")
        .attr("transform", "translate(" + (sankey.nodeWidth()/2) + "," + 0 + ")")
        .style("text-anchor", "middle")
        .text(function(d) {
            return d.name;
        })
        .style("font-size", adaptLabelFontSize)
        .call(wrap, sankey.nodeWidth())
        .filter(function(d) {
            return d.x < width / 2;
        });

    node
        .on("mouseover", function(d, i) {
            tip.transition()    
                .duration(200)    
                .style("opacity", .9);    
            tip.html("<p>" + d.name + "</p><p>" + format(d.value) + "</p>")

            link.style("opacity", "0.1");
            node.style("opacity", "0.1");
            valoriseAdjacentLinks(link, d).style("opacity", "0.8");
            valoriseAdjacentNodes(node, link, d, currentFilters).style("opacity", "0.8");
          })
        .on("mouseout", function(d, i) {
            applyDefaultOpacity(node, link);

            tip.transition()    
                .duration(500)    
                .style("opacity", 0); 
        });

    link
        .on("mouseover", function(d, i) {
            tip.transition()    
                .duration(200)    
                .style("opacity", .8);    
            tip.html("<p>" + d.source.name + " → " + d.target.name + "</p><p>" + d.linktype + "</p>")
                .style("left", (d3.event.pageX) + "px")   
                .style("top", (d3.event.pageY - 28) + "px");

            var currentLink = d3.select(this);
            link.style("opacity", "0.1");
            node.style("opacity", "0.1");
            currentLink.style("opacity", "0.8");
            valoriseNodesOnLinkHover(node, currentLink).style("opacity", "0.8");
          })
        .on("mouseout", function(d, i) {
            applyDefaultOpacity(node, link);

            tip.transition()    
                .duration(500)    
                .style("opacity", 0); 
        });

    function dragmove(d) {
        d3.select(this)
            .attr("transform",
                "translate(" +
                d.x + "," +
                (d.y = Math.max(
                    0, Math.min(height - d.dy, d3.event.y))) + ")");
        sankey.relayout();
        link.attr("d", path);
    }

});


// NOTE : Il est possible de refactorer le code de certaines fonctions en créant
// une fonction de parcours des source/targetLinks et peut etre aussi
// en utilisant includes()

function wrap(text, width) {
  text.each(function() {
    var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0,
        lineHeight = 1.1, // ems
        y = text.attr("y"),
        dy = parseFloat(text.attr("dy")),
        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
    while (word = words.pop()) {
      line.push(word);
      tspan.text(line.join(" "));
      if (tspan.node().getComputedTextLength() > width) {
        line.pop();
        tspan.text(line.join(" "));
        line = [word];
        tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
      }
    }
  });
}

function adaptLabelFontSize(d) {
  
  var xPadding, labelAvailableWidth, labelWidth;
  xPadding = 8;
  labelAvailableWidth = sankey.nodeWidth() - xPadding;
  labelWidth = this.getComputedTextLength();

  // There is enough space for the label so leave it as is.
  if (labelWidth < labelAvailableWidth) {
    return null;
  }
  /*
   * The meaning of the ratio between labelAvailableWidth and labelWidth equaling 1 is that
   * the label is taking up exactly its available space.
   * With the result as `1em` the font remains the same.
   *
   * The meaning of the ratio between labelAvailableWidth and labelWidth equaling 0.5 is that
   * the label is taking up twice its available space.
   * With the result as `0.5em` the font will change to half its original size.
   */
  return (labelAvailableWidth / labelWidth) + 'em';
}

// PARAM : un tableau de noeuds représentants les UEs [arrayCourse]
// et une compétence pour filtrer les UEs [skill]
// RETURN : renvoie un tableau comportant les UEs en lien avec la compétence
function getCourseBySkill(arrayCourse, skill) {
    return arrayCourse.filter(function(d, i) {

        var skillArray = d.dependances,
            bool = false;

        skillArray.forEach(function(d, i) {
            if (d[0] === skill) {
                bool = true;
            }
        })

        return bool;
    })
}

// PARAM : un tableau de noeuds représentants les UEs [arrayCourse]
// RETURN : renvoie un tableau de liens de dépendances entre UEs
function getLinks(arrayCourse) {
    var links = [];

    arrayCourse.forEach(function(d, i) {
        d.dependances.forEach(function(din) {
            for (var j = 1; j < din.length; j++) {
                links.push({
                    "source": +d.ueid,
                    "linktype": din[0],
                    "target": +din[j],
                    "value": d.value
                });
            }
        })
    })

    return links;
}

// PARAM : un tableau de noeuds représentants les UEs [courseArray]
// et un entier représentant un id d'UE [courseId]
// RETURN : renvoie l'UE correspondant à l'id [courseId]
function getCourseById(courseArray, courseId) {
    var course = courseArray.filter(function(d) {
        return +d.ueid === courseId;
    })

    if (course.length && course[0])
        return course[0];
}

// PARAM : tableau d'UEs [arrayCourse]
// RETURN : tableau [min,max] des valeurs de semestre (ex pour la licence : [1,6])
function getMinMaxSemester(arrayCourse) {
    return d3.extent(arrayCourse, function(d) {
        return +d.semestre;
    })
}

// PARAM : element considéré pour le zoom [tagToTransform]
// et multiplicateur max du zoom [maxZoom]
function zoomHandler(tagToTransform, maxZoom) {
    d3.selection().call(d3.zoom()
        .scaleExtent([1 / 2, maxZoom])
        .translateExtent([
            [-width, -height],
            [2 * width + margin.right, 2 * height + margin.bottom]
        ])
        .on("zoom", zoomingDoc));

    function zoomingDoc() {
        tagToTransform.attr("transform", d3.event.transform);
    }
}

// PARAM : selection d3 de liens [links] entre UEs
// RETURN : void, affiche les liens avec une couleur différente selon la
// compétence mise en jeu
function displayLinks(links) {

    links.style("stroke", function(d) {
        switch (d.linktype) {
            case "Realiser":
                return color(0.16);
                break;
            case "Appliquer":
                return color(0.32);
                break;
            case "Formaliser":
                return color(0.50)
                break;
            case "Construire":
                return color(0.66)
                break;
            case "Programmer":
                return color(0.83)
                break;
            case "Professionnaliser":
                return color(1)
                break;

            default:

        }
    })
}

// PARAM : selection d3 de liens [links] entre UEs
// RETURN : void, fait disparaitre les liens links à l'affichage
function hideLinks(links) {
    links.style("stroke", "none");
}

// PARAM : selection d3 de noeuds-UEs [nodes] à afficher
// RETURN : void, affiche les noeuds [nodes]
function displayNodes(nodes) {
    nodes.style("display", "block");
}

// PARAM : selection d3 de noeuds-UEs [nodes] à cacher
// RETURN : void, fait disparaitre les liens noeuds-UEs à l'affichage
function hideNodes(nodes) {
    nodes.style("display", "none");
}

// PARAM : selection d3 de liens [links], de noeuds [nodes], et filtres [...skill]
// RETURN : tableau de filtres appliqués, gere l'affichage en fonction du filtrage
function filterSkill(links, nodes, ...skill) {

    var displayedLinks = links.filter(function(d) {
        var containsFilter = false;
        skill.forEach(function(ds, is) {
            if (ds === d.linktype) {
                containsFilter = true;
            }
        });
        return containsFilter;
    })
    hideLinks(links);
    displayLinks(displayedLinks);

    var displayedNodes = nodes.filter(function(d) {
        var containsFilter = false;
        d.dependances.forEach(function(ddep, idep) {
            skill.forEach(function(ds, is) {
                if (ddep[0] && (ddep[0] === ds))
                    containsFilter = true;
            });
        })
        return containsFilter;
    });
    hideNodes(nodes);
    displayNodes(displayedNodes);

    return skill;
}

// PARAM : selection d3 des liens [links] et du noeud [node] à mettre en valeur
// RETURN : selection d3 comportant tous les liens dont le noeud [node] est la
// source ou la destination
function valoriseAdjacentLinks(links, node) {

    return links.filter(function(d) {
        var containsFilter = false;
        var containsFilter2 = false;
        node.targetLinks.forEach(
            function(din) {
                if (d.target === din.target) {
                    containsFilter = true;
                }
            }
        )

        node.sourceLinks.forEach(
            function(din) {
                if (d.source === din.source) {
                    containsFilter2 = true;
                }
            }
        )
        return containsFilter || containsFilter2;
    });
}

// PARAM : selection d3 des liens [links], des noeuds [nodes]
// et du noeud [node] à mettre en valeur
// RETURN : void, gere l'affichage en fonction du filtrage
function valoriseAdjacentNodes(nodes, links, node, currentFilters) {
    return nodes.filter(function(dn) {
        var containsFilter = false;

        links.each(function(d) {
            if (((dn === d.source && d.target === node) ||
                    (dn === d.target && d.source === node) ||
                    (node === dn)) &&
                currentFilters.includes(d.linktype)) {
                containsFilter = true;
            }
        })

        return containsFilter;
    })

}

// PARAM : selection d3 des liens [links], des noeuds [nodes]
// RETURN : void, remet l'opacité des liens et des noeuds par défaut
function applyDefaultOpacity(nodes, links) {
    nodes.style("opacity", "0.8");
    links.style("opacity", "0.8");
}

// PARAM : selection d3 des liens des noeuds [nodes] et lien courant qui est
// onmouseover [link]
// RETURN : selection d3 des noeuds qui sont aux extrémités du lien [link]
function valoriseNodesOnLinkHover(nodes, link) {
    return nodes.filter(function(d) {
        return (link.datum().source === d || link.datum().target === d);
    })
}

function applyColours(d) {
  return d.color = color(d.name.replace(/ .*/, ""));
}
